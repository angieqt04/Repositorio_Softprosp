CREATE FUNCTION path_contain_pt (path, point) RETURNS boolean
	LANGUAGE sql
AS $$
select pg_catalog.on_ppath($2, $1)
$$
