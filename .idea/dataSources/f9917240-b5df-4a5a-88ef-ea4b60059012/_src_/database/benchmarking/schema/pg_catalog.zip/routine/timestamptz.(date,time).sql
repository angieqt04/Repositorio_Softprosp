CREATE FUNCTION timestamptz (date, time without time zone) RETURNS timestamp with time zone
	LANGUAGE sql
AS $$
select cast(($1 + $2) as timestamp with time zone)
$$
